import tkinter as tk
from tkinter import filedialog
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
import csv

class EmailSender:
    def __init__(self, root):
        self.root = root
        self.root.title("Email Sender")
        self.root.geometry("400x300")
        self.csv_path = tk.StringVar()
        self.email = tk.StringVar()
        self.password = tk.StringVar()
        
        # Create GUI widgets
        tk.Label(self.root, text="CSV file:").pack()
        tk.Entry(self.root, textvariable=self.csv_path, width=40).pack()
        tk.Button(self.root, text="Browse", command=self.browse_csv).pack(pady=10)
        tk.Label(self.root, text="Email:").pack()
        tk.Entry(self.root, textvariable=self.email, width=40).pack()
        tk.Label(self.root, text="Password:").pack()
        tk.Entry(self.root, textvariable=self.password, width=40, show="*").pack()
        tk.Button(self.root, text="Send Emails", command=self.send_emails).pack(pady=20)
    
    def browse_csv(self):
        # Open a file dialog to select a CSV file
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        self.csv_path.set(file_path)
    
    def send_emails(self):
        # Read data from CSV file
        with open(self.csv_path.get(), 'r') as file:
            reader = csv.reader(file)
            next(reader)  # skip header row
            for row in reader:
                # Extract data from CSV row
                to_address = row[0]
                subject = row[1]
                body = row[2]
                image_path = row[3]
                pdf_path = row[4]
        
                # Create email message
                msg = MIMEMultipart()
                msg['From'] = self.email.get()
                msg['To'] = to_address
                msg['Subject'] = subject
        
                # Add body text to email
                text = MIMEText(body)
                msg.attach(text)
        
                # Add image attachment to email
                if image_path:
                    with open(image_path, 'rb') as file:
                        img = MIMEImage(file.read(), name='image.jpg')
                        msg.attach(img)
        
                # Add PDF attachment to email
                if pdf_path:
                    with open(pdf_path, 'rb') as file:
                        pdf = MIMEApplication(file.read(), name='document.pdf')
                        msg.attach(pdf)
        
                # Send email
                with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
                    smtp.starttls()
                    smtp.login(self.email.get(), self.password.get())
                    smtp.send_message(msg)
        
        # Show a message box when all emails have been sent
        tk.messagebox.showinfo("Emails sent", "All emails have been sent!")
        
if __name__ == "__main__":
    root = tk.Tk()
    app = EmailSender(root)
    root.mainloop()
